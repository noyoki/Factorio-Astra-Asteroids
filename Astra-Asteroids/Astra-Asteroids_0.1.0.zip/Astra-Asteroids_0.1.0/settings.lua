
data:extend ({
	{	
		name = "astra-include-crude-asteroid",
		setting_type = "startup",
		type = "bool-setting",
		default_value = true,
		order ="0"
	}
})
