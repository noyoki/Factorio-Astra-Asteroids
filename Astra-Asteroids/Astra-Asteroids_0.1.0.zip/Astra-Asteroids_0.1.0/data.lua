require("data.prototypes.asteroids.Crude_Asteroid")
require("data.prototypes.asteroids.Sunrise_Sasparillaroid")
require("data.prototypes.planets.nauvis")